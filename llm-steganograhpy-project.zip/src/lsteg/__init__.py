"""Shared-key linguistic steganography research toolkit."""

__all__ = ["__version__"]

__version__ = "0.1.0"
